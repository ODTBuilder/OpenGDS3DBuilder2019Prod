# README #

This project has been superseed by https://github.com/markaren/three.kt (which actually works)