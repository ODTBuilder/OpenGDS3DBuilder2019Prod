/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.laht.threej.objects;

import info.laht.threej.core.Object3D;

/**
 *
 * @author laht
 */
public class Group extends Object3D {
    
    public final String type = "Group";
    
}
