/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.laht.threej.gl;

/**
 *
 * @author laht
 */
public class GLCapabilities {
    
    private Integer maxAnisotropy;
    
    public GLCapabilities() {
        
    }

    public int getMaxAnisotropy() {
        
        if (maxAnisotropy != null) {
            return maxAnisotropy;
        }
        
        return maxAnisotropy;
    }
    
    
    
}
